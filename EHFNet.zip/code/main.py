# -*- coding: utf-8 -*-
import shutil
from datetime import datetime

from config import arg_config, proj_root
from utils.misc import (
    construct_exp_name,
    construct_path,
    construct_print,
    pre_mkdir,
    set_seed,
)
from utils.solver import Solver
import os

__all__ = ["proj_root", "arg_config"]

proj_root = os.path.dirname(__file__)


def calculate_flops(model, input_size, device):
    """
    专门为您的EHFNet模型优化的FLOPs计算函数
    """
    try:
        from thop import profile, clever_format
        import torch

        # 1. 模型准备 - 使用CPU更稳定
        original_device = next(model.parameters()).device
        model_cpu = model.cpu()
        model_cpu.eval()

        # 2. 创建输入张量
        input_tensor = torch.randn(1, 3, input_size, input_size)

        # 3. 关键步骤：先运行一次前向传播初始化所有动态层
        with torch.no_grad():
            try:
                # 这一步很重要：初始化EHFF模块中的upper_align等动态层
                init_output = model_cpu(input_tensor.clone())

            except Exception as e:
                pass

        # 4. 计算FLOPs
        flops, params = profile(model_cpu, inputs=(input_tensor,), verbose=False)

        # 5. 格式化结果
        flops_str, params_str = clever_format([flops, params], "%.3f")
        gflops = flops / 1e9

        # 6. 恢复模型到原设备
        model.to(original_device)
        print(f"   FLOPs: {flops_str}")
        print(f"   GFLOPs: {gflops:.3f}G")

        return flops, flops_str, params_str

    except Exception as e:
        print(f"FLOPs计算失败: {str(e)}")

        # 降级方案1：尝试更小的输入尺寸
        if input_size > 224:
            try:
                model.to(original_device)
            except:
                pass
            return calculate_flops(model, 224, device)

        # 降级方案2：估算FLOPs
        try:
            total_params = sum(p.numel() for p in model.parameters())
            # 基于参数量的粗略估算（ResNet系列的经验值）
            estimated_flops = total_params * 12

            try:
                model.to(original_device)
            except:
                pass

            print(f"🔧 使用估算值: {estimated_flops / 1e9:.3f}G FLOPs")
            return (estimated_flops,
                    f"{estimated_flops / 1e9:.3f}G (估算)",
                    f"{total_params / 1e6:.3f}M")
        except:
            return None, "计算失败", "N/A"


if __name__ == '__main__':
    init_start = datetime.now()
    exp_name = construct_exp_name(arg_config)
    path_config = construct_path(
        proj_root=proj_root,
        exp_name=exp_name,
        xlsx_name=arg_config["xlsx_name"],
        # size_list=[224, 256],
    )
    pre_mkdir(path_config)
    set_seed(seed=0, use_cudnn_benchmark=False)

    # for train_i in range(1, 4):
    solver = Solver(exp_name, arg_config, path_config)

    # 计算模型参数量
    total_params = sum(p.numel() for p in solver.net.parameters())
    model_name = arg_config.get("model", solver.net.__class__.__name__)

    # 计算FLOPs
    input_size = arg_config.get("input_size", 352)
    flops, flops_str, params_str = calculate_flops(solver.net, input_size, solver.dev)

    # 输出模型信息
    msg = "Model based on {} have {:.4f}Mb parameters in total".format(
        model_name, total_params / 1e6
    )
    print(msg)  # 控制台可见
    construct_print(msg)

    # 输出FLOPs信息
    if flops is not None:
        flops_msg = "Model FLOPs: {} (input size: {}x{})".format(
            flops_str, input_size, input_size
        )
        print(flops_msg)
        construct_print(flops_msg)

        # 同时输出G FLOPs
        gflops = flops / 1e9
        gflops_msg = "Model GFLOPs: {:.3f}G".format(gflops)
        print(gflops_msg)
        construct_print(gflops_msg)
    else:
        fallback_msg = "FLOPs calculation unavailable"
        print(fallback_msg)
        construct_print(fallback_msg)

    shutil.copy(proj_root + "/config.py", path_config["cfg_log"])
    shutil.copy(proj_root + "/utils/solver.py", path_config["trainer_log"])

    if arg_config["resume_mode"] == "test":
        solver.test()
    else:
        solver.train()