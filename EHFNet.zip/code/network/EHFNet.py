# -*- coding: utf-8 -*-
"""
MEAHANet (CSEPNet) - 参数优化版本
通过渐进式通道缩减策略减少参数量，同时保持细节和语义信息

优化策略：
1. 低层特征通道数减少25%（保持细节信息）
2. 高层特征通道数减少25%（保持语义信息）
3. SMT辅助分支减少33%（辅助分支可以更激进）
4. 解码器统一通道从64降到48
5. 使用分组卷积和深度可分离卷积进一步减少参数
6. 降低注意力机制的reduction ratio以补偿通道减少
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from backbone.origin.from_origin import Backbone_ResNet50_in3, Backbone_VGG16_in3
from module.BaseBlocks import BasicConv2d, AsymmetricConvBlock
from module.MyModule import *
from utils.tensor_ops import cus_sample

class DepthwiseSeparableConv(nn.Module):
    """3x3 depthwise + 1x1 pointwise"""
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.dw = nn.Conv2d(in_ch, in_ch, 3, padding=1, groups=in_ch, bias=False)
        self.pw = nn.Conv2d(in_ch, out_ch, 1, bias=False)
    def forward(self, x):
        return self.pw(self.dw(x))

# ============ 基础模块 ============
class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class TransBasicConv2d(nn.Module):
    """转置卷积基础块"""

    def __init__(self, in_planes, out_planes, kernel_size=2, stride=2, padding=0, dilation=1, bias=False):
        super(TransBasicConv2d, self).__init__()
        self.Deconv = nn.ConvTranspose2d(in_planes, out_planes,
                                         kernel_size=kernel_size, stride=stride,
                                         padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.Deconv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class AsymmetricConvBlock(nn.Module):
    """非对称卷积块，包含3×3、1×3、3×1卷积"""

    def __init__(self, in_channels, out_channels):
        super(AsymmetricConvBlock, self).__init__()

        # 3×3卷积
        self.conv_3x3 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False)
        # 1×3卷积
        self.conv_1x3 = nn.Conv2d(in_channels, out_channels, kernel_size=(1, 3), padding=(0, 1), bias=False)
        # 3×1卷积
        self.conv_3x1 = nn.Conv2d(in_channels, out_channels, kernel_size=(3, 1), padding=(1, 0), bias=False)

        self.bn = nn.BatchNorm2d(out_channels * 3)
        self.relu = nn.ReLU(inplace=True)

        # 输出通道调整
        self.conv_out = nn.Conv2d(out_channels * 3, out_channels, kernel_size=1, bias=False)
        self.bn_out = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        # 并行执行三种卷积
        out_3x3 = self.conv_3x3(x)
        out_1x3 = self.conv_1x3(x)
        out_3x1 = self.conv_3x1(x)

        # 级联
        out = torch.cat([out_3x3, out_1x3, out_3x1], dim=1)
        out = self.bn(out)
        out = self.relu(out)

        # 通道调整
        out = self.conv_out(out)
        out = self.bn_out(out)
        out = self.relu(out)

        return out


# ============ 注意力模块 ============
class ChannelAttention(nn.Module):
    """通道注意力 - 参数优化版本"""

    def __init__(self, in_planes, ratio=8):  # 降低ratio以补偿通道数减少
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        # 确保中间通道数至少为8
        mid_planes = max(8, in_planes // ratio)

        self.fc = nn.Sequential(
            nn.Conv2d(in_planes, mid_planes, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_planes, in_planes, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttentionWithSobel(nn.Module):
    """带Sobel边缘检测的空间注意力"""

    def __init__(self, kernel_size=7):
        super(SpatialAttentionWithSobel, self).__init__()
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

        # Sobel算子
        self.register_buffer('sobel_x',
                             torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32).view(1, 1, 3, 3))
        self.register_buffer('sobel_y',
                             torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32).view(1, 1, 3, 3))

        self.edge_conv = nn.Conv2d(1, 1, 3, padding=1, bias=False)

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)

        # Sobel边缘检测
        edge_x = F.conv2d(avg_out, self.sobel_x, padding=1)
        edge_y = F.conv2d(avg_out, self.sobel_y, padding=1)
        edge_magnitude = torch.sqrt(edge_x ** 2 + edge_y ** 2 + 1e-8)
        edge_enhanced = self.edge_conv(edge_magnitude)

        # 标准空间注意力
        spatial_out = torch.cat([avg_out, max_out], dim=1)
        spatial_out = self.conv1(spatial_out)

        # 结合边缘信息
        out = self.sigmoid(spatial_out + 0.5 * edge_enhanced)
        return out


# ============ SMT分支模块 ============
class MHMC(nn.Module):
    """Multi-Head Mixed Convolution"""

    def __init__(self, channels, num_heads=4):
        super(MHMC, self).__init__()
        self.num_heads = num_heads
        self.channels_per_head = channels // num_heads

        self.dw_convs = nn.ModuleList()
        for i in range(num_heads):
            kernel_size = 3 + 2 * i  # 3, 5, 7, 9
            padding = kernel_size // 2
            self.dw_convs.append(
                nn.Conv2d(self.channels_per_head, self.channels_per_head,
                          kernel_size, padding=padding, groups=self.channels_per_head, bias=False)
            )

    def forward(self, x):
        b, c, h, w = x.shape
        x_split = x.chunk(self.num_heads, dim=1)

        outputs = []
        for i, conv in enumerate(self.dw_convs):
            outputs.append(conv(x_split[i]))

        return torch.cat(outputs, dim=1)


class SAA(nn.Module):
    """Scale-Aware Aggregation"""

    def __init__(self, channels, num_heads=4):
        super(SAA, self).__init__()
        self.num_heads = num_heads
        self.groups = channels // num_heads

        # 组内聚合
        self.intra_conv = nn.Conv2d(num_heads, num_heads * 2, 1, bias=False)
        self.intra_conv2 = nn.Conv2d(num_heads * 2, num_heads, 1, bias=False)

        # 组间聚合
        self.inter_conv = nn.Conv2d(channels, channels, 1, bias=False)

    def forward(self, x):
        b, c, h, w = x.shape
        # 重排列：从[B, C, H, W] -> [B, groups, heads, H, W]
        x_grouped = x.view(b, self.groups, self.num_heads, h, w)

        # 组内聚合
        x_intra = x_grouped.permute(0, 2, 1, 3, 4).contiguous().view(b, self.num_heads, -1, h * w)
        x_intra = x_intra.mean(dim=2, keepdim=True).view(b, self.num_heads, h, w)

        x_intra = self.intra_conv(x_intra)
        x_intra = F.relu(x_intra)
        x_intra = self.intra_conv2(x_intra)

        # 广播回原始形状
        x_intra = x_intra.unsqueeze(2).expand(b, self.num_heads, self.groups, h, w)
        x_intra = x_intra.contiguous().view(b, c, h, w)

        # 组间聚合
        out = self.inter_conv(x + x_intra)
        return out


class SAM(nn.Module):
    """Scale-Aware Modulation"""

    def __init__(self, channels, num_heads=4):
        super(SAM, self).__init__()
        self.mhmc = MHMC(channels, num_heads)
        self.saa = SAA(channels, num_heads)
        self.value_conv = nn.Conv2d(channels, channels, 1, bias=False)
        self.modulator_conv = nn.Conv2d(channels, channels, 1, bias=False)

    def forward(self, x):
        # 计算调制器
        modulator = self.mhmc(x)
        modulator = self.saa(modulator)
        modulator = self.modulator_conv(modulator)

        # 计算值
        value = self.value_conv(x)

        # 元素级相乘
        out = modulator * value
        return out


class MSA(nn.Module):
    """Multi-Head Self-Attention"""

    def __init__(self, channels, num_heads=8):
        super(MSA, self).__init__()
        self.num_heads = num_heads
        self.head_dim = channels // num_heads
        self.scale = self.head_dim ** -0.5

        self.qkv = nn.Linear(channels, channels * 3, bias=False)
        self.proj = nn.Linear(channels, channels)

    def forward(self, x):
        b, c, h, w = x.shape
        x_flat = x.flatten(2).transpose(1, 2)  # [B, H*W, C]

        qkv = self.qkv(x_flat).reshape(b, h * w, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)

        out = (attn @ v).transpose(1, 2).reshape(b, h * w, c)
        out = self.proj(out)

        return out.transpose(1, 2).reshape(b, c, h, w)


class MixBlock(nn.Module):
    """混合块：SAM + MSA"""

    def __init__(self, channels):
        super(MixBlock, self).__init__()
        self.sam = SAM(channels)
        self.msa = MSA(channels)
        self.ln1 = nn.LayerNorm(channels)
        self.ln2 = nn.LayerNorm(channels)

    def forward(self, x):
        # SAM分支
        sam_out = self.sam(x)

        # MSA分支
        b, c, h, w = x.shape
        x_ln = self.ln1(x.flatten(2).transpose(1, 2)).transpose(1, 2).reshape(b, c, h, w)
        msa_out = self.msa(x_ln)
        msa_out = self.ln2(msa_out.flatten(2).transpose(1, 2)).transpose(1, 2).reshape(b, c, h, w)

        return sam_out + msa_out


# ============ 融合和增强模块 ============
class EHFF(nn.Module):
    """
    Edge-aware Heterogeneous Feature Fusion (EHFF)
    对应论文式(3)–(12)、图5：
      - CNN分支：LCEM  -> (3)(4)(5)
      - SMT分支：GSEM  -> (6)(7)
      - 融合与空间注意+Sobel -> (8)(9)
      - 自顶向下递归(含上层特征)：-> (10)，i=1 时遵循 (11)(12)
    兼容原 EHFF 的接口：
      __init__(f_channels, a_channels)
      forward(f, a, upper_z=None) -> z_i
    """
    def __init__(self, f_channels: int, a_channels: int):
        super().__init__()
        self.f_channels = f_channels

        # -------- 通道/尺寸对齐 --------
        self.align_a = nn.Conv2d(a_channels, f_channels, 1, bias=False) if a_channels != f_channels else nn.Identity()

        # -------- CNN分支：LCEM --------
        # Avg 5x5 作 Pavg，GN 稳定分布；β 为可学习缩放
        self.avg5 = nn.AvgPool2d(kernel_size=5, stride=1, padding=2)
        # 论文(5)中的 SE，这里直接复用通道注意力（等价于 SE）
        self.se_f = nn.Sequential(
            nn.Conv2d(f_channels, max(8, f_channels // 8), 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(max(8, f_channels // 8), f_channels, 1, bias=False),
            nn.Sigmoid()
        )
        self.gn_f = nn.GroupNorm(1, f_channels)  # GN(1, C) 等价于跨通道归一化，安全不挑 group
        self.beta = nn.Parameter(torch.tensor(1.0))

        # -------- SMT分支：GSEM --------
        red = max(8, f_channels // 4)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.mlp_a = nn.Sequential(
            nn.Conv2d(f_channels, red, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(red, f_channels, 1, bias=False),
            nn.Sigmoid()
        )
        self.dws_smooth = DepthwiseSeparableConv(f_channels, f_channels)
        self.gamma = nn.Parameter(torch.tensor(1.0))

        # -------- 跨模态融合 T：Conv1x1 -> DWSConv -> BN -> ReLU --------
        self.fuse_1x1 = nn.Conv2d(f_channels * 2, f_channels, 1, bias=False)
        self.fuse_dws = DepthwiseSeparableConv(f_channels, f_channels)
        self.fuse_bn  = nn.BatchNorm2d(f_channels)

        # -------- 空间注意 + Sobel 边缘先验 --------
        self.sa_conv = nn.Conv2d(2, 1, kernel_size=7, padding=3, bias=False)
        self.edge_conv = nn.Conv2d(1, 1, kernel_size=3, padding=1, bias=False)
        # Sobel 卷积核（对均值图）
        self.register_buffer('sobel_x', torch.tensor([[-1, 0, 1],
                                                     [-2, 0, 2],
                                                     [-1, 0, 1]], dtype=torch.float32).view(1, 1, 3, 3))
        self.register_buffer('sobel_y', torch.tensor([[-1, -2, -1],
                                                     [ 0,  0,  0],
                                                     [ 1,  2,  1]], dtype=torch.float32).view(1, 1, 3, 3))

        # -------- 上层 z 的动态通道对齐（仅在首次用到时创建）--------
        self.upper_align: nn.Module | None = None

    @staticmethod
    def _resize_like(src: torch.Tensor, ref: torch.Tensor) -> torch.Tensor:
        if src.shape[2:] != ref.shape[2:]:
            src = F.interpolate(src, size=ref.shape[2:], mode='bilinear', align_corners=False)
        return src

    def forward(self, f: torch.Tensor, a: torch.Tensor, upper_z: torch.Tensor | None = None) -> torch.Tensor:
        # 1) 尺寸/通道对齐
        a = self._resize_like(a, f)
        a_aligned = self.align_a(a)

        # 2) CNN分支：LCEM（式(3)(4)(5)）
        # x = f - Avg5x5(f)
        x = f - self.avg5(f)
        # δ = x * (1 + α * tanh(x)), α=0.6
        delta = x * (1.0 + 0.6 * torch.tanh(x))
        # SE 权重 + 可学习缩放 β
        w_se = self.se_f(f)
        f_enh = self.gn_f(f + delta * w_se * self.beta)

        # 3) SMT分支：GSEM（式(6)(7)）
        w_a = self.mlp_a(self.gap(a_aligned))           # ωsigmoid
        a_mod = a_aligned * w_a                          # a' ⊙ ω
        a_smooth = self.dws_smooth(a_mod)                # DWSConv 平滑
        a_enh = a_aligned + self.gamma * a_smooth        # 残差调制

        # 4) 跨模态融合 T（式(9)）
        T = torch.cat([f_enh, a_enh], dim=1)
        T = self.fuse_1x1(T)
        T = self.fuse_dws(T)
        T = self.fuse_bn(T)
        T = F.relu(T, inplace=True)

        # 5) 空间注意 + Sobel 先验（式(8)）
        avg_map = torch.mean(T, dim=1, keepdim=True)
        max_map, _ = torch.max(T, dim=1, keepdim=True)
        sa_core = self.sa_conv(torch.cat([avg_map, max_map], dim=1))  # SA(mean,max)

        edge_x = F.conv2d(avg_map, self.sobel_x, padding=1)
        edge_y = F.conv2d(avg_map, self.sobel_y, padding=1)
        edge_mag = torch.sqrt(edge_x ** 2 + edge_y ** 2 + 1e-8)
        edge_term = self.edge_conv(edge_mag)

        w_sa = torch.sigmoid(sa_core + 0.8 * edge_term)  # ω_sa

        # 6) 顶向下递归（式(10)；i=1 时等价于式(11)(12)的形态）
        T_att = T * w_sa

        z_next = None
        if upper_z is not None:
            upper_z = self._resize_like(upper_z, T_att)
            if (self.upper_align is None) or (self.upper_align.in_channels != upper_z.shape[1]):
                self.upper_align = nn.Conv2d(upper_z.shape[1], self.f_channels, 1, bias=False).to(upper_z.device)
            z_next = self.upper_align(upper_z)

        if z_next is None:
            out = T_att + f + a_aligned          # i=4 时对应 z5=0
        else:
            out = T_att + f + a_aligned + z_next # i=3/2/1 时加上 z_{i+1}

        return out


class EHFF_F1(nn.Module):
    """
    EHFF variant for i=1 (fuse f1 & z2):
      - CNN分支: LCEM (式(3)(4)(5))
      - Top-down分支: GSEM (式(6)(7))，对齐后的 z2 视作 'a′'
      - 融合: Conv1×1 → DWSConv → BN → ReLU (式(9))
      - 空间注意: SA(mean,max) + 0.8×Sobel边缘先验 (式(8))
      - 输出: z1 = ω_sa ⊙ T + f1 + z2 (式(12))
    接口与原 EHFF_F1 完全一致：__init__(f1_channels, z2_channels); forward(f1, z2)
    """

    def __init__(self, f1_channels: int, z2_channels: int):
        super().__init__()
        self.f1_channels = f1_channels

        # ========== 尺寸/通道对齐（i=1：先双线性对齐空间，再1×1通道对齐） ==========
        self.align_z2 = nn.Conv2d(z2_channels, f1_channels, 1, bias=False) \
            if z2_channels != f1_channels else nn.Identity()

        # ========== CNN分支：LCEM（式(3)(4)(5)）==========
        self.avg5 = nn.AvgPool2d(kernel_size=5, stride=1, padding=2)   # Pavg
        mid_se = max(8, f1_channels // 8)
        self.se_f1 = nn.Sequential(                                 # SE
            nn.Conv2d(f1_channels, mid_se, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_se, f1_channels, 1, bias=False),
            nn.Sigmoid()
        )
        self.gn_f1 = nn.GroupNorm(1, f1_channels)                   # GN(1,C)
        self.beta = nn.Parameter(torch.tensor(1.0))                 # 可学习缩放 β

        # ========== 顶向下分支：GSEM（式(6)(7)）==========
        red = max(8, f1_channels // 4)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.mlp_z2 = nn.Sequential(
            nn.Conv2d(f1_channels, red, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(red, f1_channels, 1, bias=False),
            nn.Sigmoid()
        )
        # DWSConv 平滑
        self.dws_smooth = nn.Sequential(
            nn.Conv2d(f1_channels, f1_channels, 3, padding=1, groups=f1_channels, bias=False),  # DW
            nn.Conv2d(f1_channels, f1_channels, 1, bias=False)                                   # PW
        )
        self.gamma = nn.Parameter(torch.tensor(1.0))

        # ========== 跨分支融合 T（式(9)）==========
        self.fuse_1x1 = nn.Conv2d(f1_channels * 2, f1_channels, 1, bias=False)
        self.fuse_dws = nn.Sequential(
            nn.Conv2d(f1_channels, f1_channels, 3, padding=1, groups=f1_channels, bias=False),
            nn.Conv2d(f1_channels, f1_channels, 1, bias=False)
        )
        self.fuse_bn = nn.BatchNorm2d(f1_channels)

        # ========== 空间注意 + Sobel 先验（式(8)）==========
        self.sa_conv = nn.Conv2d(2, 1, kernel_size=7, padding=3, bias=False)
        self.edge_conv = nn.Conv2d(1, 1, kernel_size=3, padding=1, bias=False)
        self.register_buffer('sobel_x', torch.tensor([[-1, 0, 1],
                                                      [-2, 0, 2],
                                                      [-1, 0, 1]], dtype=torch.float32).view(1, 1, 3, 3))
        self.register_buffer('sobel_y', torch.tensor([[-1, -2, -1],
                                                      [ 0,  0,  0],
                                                      [ 1,  2,  1]], dtype=torch.float32).view(1, 1, 3, 3))

    @staticmethod
    def _resize_like(src: torch.Tensor, ref: torch.Tensor) -> torch.Tensor:
        if src.shape[2:] != ref.shape[2:]:
            src = F.interpolate(src, size=ref.shape[2:], mode='bilinear', align_corners=False)
        return src

    def forward(self, f1: torch.Tensor, z2: torch.Tensor) -> torch.Tensor:
        # 1) i=1 对齐：空间+通道（论文式(11)前置说明）
        z2 = self._resize_like(z2, f1)
        z2_aligned = self.align_z2(z2)

        # 2) LCEM on f1（式(3)(4)(5)）
        x = f1 - self.avg5(f1)                              # x = PWS(f1, Pavg(f1))
        delta = x * (1.0 + 0.6 * torch.tanh(x))             # δ = x · (1 + 0.6·tanh(x))
        w_se = self.se_f1(f1)                                # SE(f1)
        f1_enh = self.gn_f1(f1 + delta * w_se * self.beta)   # GN(f1 + δ·SE(f1)·β)

        # 3) GSEM on z2（式(6)(7)）
        w = self.mlp_z2(self.gap(z2_aligned))                # ωsigmoid
        z2_mod = z2_aligned * w
        z2_smooth = self.dws_smooth(z2_mod)                  # DWSConv
        z2_enh = z2_aligned + self.gamma * z2_smooth         # 残差调制

        # 4) 融合 T（式(9)）
        T = torch.cat([f1_enh, z2_enh], dim=1)
        T = self.fuse_1x1(T)
        T = self.fuse_dws(T)
        T = self.fuse_bn(T)
        T = F.relu(T, inplace=True)

        # 5) 空间注意 + Sobel 先验（式(8)）
        avg_map = torch.mean(T, dim=1, keepdim=True)
        max_map, _ = torch.max(T, dim=1, keepdim=True)
        sa_core = self.sa_conv(torch.cat([avg_map, max_map], dim=1))
        edge_x = F.conv2d(avg_map, self.sobel_x, padding=1)
        edge_y = F.conv2d(avg_map, self.sobel_y, padding=1)
        edge_mag = torch.sqrt(edge_x ** 2 + edge_y ** 2 + 1e-8)
        edge_term = self.edge_conv(edge_mag)
        w_sa = torch.sigmoid(sa_core + 0.8 * edge_term)      # 0.8 系数来自式(8)

        T_att = T * w_sa

        # 6) 输出（式(12)）：z1 = ωsa ⊙ T + f1 + z2
        out = T_att + f1 + z2_aligned
        return out

class ERFE(nn.Module):
    """Edge-Refined Multi-Scale Feature Enhancement - 参数优化版"""

    def __init__(self, channels):
        super(ERFE, self).__init__()
        self.channels = channels

        # 上层特征融合 - 使用深度可分离卷积
        self.upper_fusion = nn.Sequential(
            nn.Conv2d(channels * 2, channels, 1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False),  # DW
            nn.Conv2d(channels, channels, 1, bias=False),  # PW
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True)
        )

        self.conv1 = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=max(1, channels // 4), bias=False),
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True)
        )

        # 边界增强 - 已经是深度可分离结构
        self.boundary_enhance = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False),
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True)
        )

        self.conv2 = nn.Sequential(
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.GroupNorm(min(32, max(1, channels // 2)), channels),  # 适应更小的通道数
            nn.ReLU(inplace=True)
        )

        self.l2_norm = nn.GroupNorm(1, channels)
        self.upper_align = None

    def forward(self, z, upper_f=None):
        if upper_f is not None:
            if upper_f.shape[2:] != z.shape[2:]:
                upper_f = F.interpolate(upper_f, size=z.shape[2:], mode='bilinear', align_corners=False)

            if self.upper_align is None or self.upper_align.in_channels != upper_f.shape[1]:
                self.upper_align = nn.Conv2d(upper_f.shape[1], self.channels, 1, bias=False).to(upper_f.device)

            upper_f_aligned = self.upper_align(upper_f)
            z = torch.cat([z, upper_f_aligned], dim=1)
            z = self.upper_fusion(z)

        g1 = self.conv1(z)
        enhanced_g1 = self.boundary_enhance(g1) * 0.2
        g2 = self.l2_norm(enhanced_g1)
        g2 = self.conv2(g2)
        out = enhanced_g1 * g2

        return out


# ============ 解码器 ============
class decoder_optimized(nn.Module):
    """优化的多尺度解码器 - 统一到48通道"""

    def __init__(self, in_channels, unified_channels=48):
        super(decoder_optimized, self).__init__()

        # 统一通道数
        self.unified_channels = unified_channels

        # 通道统一层 - 根据输入通道数动态创建
        self.channel_conv1 = nn.Conv2d(in_channels[0], unified_channels, 1)
        self.channel_conv2 = nn.Conv2d(in_channels[1], unified_channels, 1)
        self.channel_conv3 = nn.Conv2d(in_channels[2], unified_channels, 1)
        self.channel_conv4 = nn.Conv2d(in_channels[3], unified_channels, 1)

        # 解码器模块 - 使用优化的通道数
        self.decoder4 = nn.Sequential(
            BasicConv2d(unified_channels, unified_channels, 3, padding=1),
            BasicConv2d(unified_channels, unified_channels, 3, padding=1),
            nn.Dropout(0.3),
            TransBasicConv2d(unified_channels, unified_channels, kernel_size=2, stride=2)
        )
        self.S4 = nn.Conv2d(unified_channels, 1, 3, stride=1, padding=1)

        self.decoder3 = nn.Sequential(
            BasicConv2d(unified_channels, unified_channels, 3, padding=1),
            BasicConv2d(unified_channels, unified_channels, 3, padding=1),
            nn.Dropout(0.3),
            TransBasicConv2d(unified_channels, unified_channels, kernel_size=2, stride=2)
        )
        self.S3 = nn.Conv2d(unified_channels, 1, 3, stride=1, padding=1)

        self.decoder2 = nn.Sequential(
            BasicConv2d(unified_channels, unified_channels, 3, padding=1),
            BasicConv2d(unified_channels, unified_channels, 3, padding=1),
            nn.Dropout(0.3),
            TransBasicConv2d(unified_channels, unified_channels, kernel_size=2, stride=2)
        )
        self.S2 = nn.Conv2d(unified_channels, 1, 3, stride=1, padding=1)

        self.decoder1 = nn.Sequential(
            BasicConv2d(unified_channels, unified_channels, 3, padding=1),
            BasicConv2d(unified_channels, unified_channels, 3, padding=1),
            nn.Dropout(0.3),
            TransBasicConv2d(unified_channels, unified_channels, kernel_size=2, stride=2)
        )
        self.S1 = nn.Conv2d(unified_channels, 1, 3, stride=1, padding=1)

        # 第5个输出（最深层）
        self.decoder5 = nn.Sequential(
            BasicConv2d(unified_channels, unified_channels, 3, padding=1),
            BasicConv2d(unified_channels, unified_channels, 3, padding=1),
            nn.Dropout(0.3)
        )
        self.S5 = nn.Conv2d(unified_channels, 1, 3, stride=1, padding=1)

    def forward(self, F1, F2, F3, F4):
        # 通道统一
        x1 = self.channel_conv1(F1)
        x2 = self.channel_conv2(F2)
        x3 = self.channel_conv3(F3)
        x4 = self.channel_conv4(F4)

        # 解码和预测
        # 最深层输出
        x5_up = self.decoder5(x4)
        s5 = self.S5(x5_up)

        x4_up = self.decoder4(x4)
        s4 = self.S4(x4_up)

        x3_up = self.decoder3(x3)
        s3 = self.S3(x3_up)

        x2_up = self.decoder2(x2)
        s2 = self.S2(x2_up)

        x1_up = self.decoder1(x1)
        s1 = self.S1(x1_up)

        return s1, s2, s3, s4, s5


# ============ 主模型 ============
class EHFNet_VGG16(nn.Module):
    """基于VGG16的MEAHANet - 参数优化版本

    通道数优化策略：
    - 低层特征(f1): 64 -> 48 (减少25%，保持细节)
    - 中低层特征(f2): 96 -> 72 (减少25%)
    - 中高层特征(f3): 192 -> 144 (减少25%)
    - 高层特征(f4): 384 -> 288 (减少25%)
    - SMT分支: 48/96/192 -> 32/64/128 (减少33%，辅助分支可多减)
    - 解码器: 64 -> 48 (减少25%)
    """

    def __init__(self):
        super(EHFNet_VGG16, self).__init__()

        # 注意：这里需要导入你的backbone模块
        from ..backbone.origin.from_origin import Backbone_VGG16_in3
        from ..utils.tensor_ops import cus_sample

        self.upsample = cus_sample

        # VGG16 backbone - 保持完整性
        (
            self.encoder1,
            self.encoder2,
            self.encoder4,
            self.encoder8,
            self.encoder16,
        ) = Backbone_VGG16_in3()

        # 特征增强模块 - 优化通道数
        self.feature_enhance1 = nn.Sequential(
            AsymmetricConvBlock(64, 48),  # 64->48
            nn.Conv2d(48, 48, 1)
        )
        self.feature_enhance2 = nn.Sequential(
            AsymmetricConvBlock(128, 72),  # 128->72
            nn.Conv2d(72, 72, 1)
        )
        self.feature_enhance3 = nn.Sequential(
            AsymmetricConvBlock(256, 144),  # 256->144
            nn.Conv2d(144, 144, 1)
        )
        self.feature_enhance4 = nn.Sequential(
            AsymmetricConvBlock(512, 288),  # 512->288
            nn.Conv2d(288, 288, 1)
        )

        # SMT分支 - 更轻量化设计
        self.patch_embed = nn.Conv2d(48, 32, 3, stride=2, padding=1)  # 48->32
        self.sam_block = SAM(32)

        self.downsample1 = nn.Conv2d(32, 64, 3, stride=2, padding=1)  # 32->64
        self.mix_block = MixBlock(64)

        self.downsample2 = nn.Conv2d(64, 128, 3, stride=2, padding=1)  # 64->128
        self.msa_block = MSA(128)

        # EHFF模块 - 自适应融合
        self.ehff4 = EHFF(288, 128)  # 288+128
        self.ehff3 = EHFF(144, 64)  # 144+64
        self.ehff2 = EHFF(72, 32)  # 72+32
        self.ehff1 = EHFF_F1(48, 72)  # 48+72

        # ERFE模块
        self.erfe4 = ERFE(288)
        self.erfe3 = ERFE(144)
        self.erfe2 = ERFE(72)
        self.erfe1 = ERFE(48)

        # 深度监督解码器 - 优化版
        self.decoder = decoder_optimized(
            in_channels=[48, 72, 144, 288],
            unified_channels=48  # 统一通道数从64降到48
        )

        # 修复：正确的上采样操作
        self.upsample4 = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True)
        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)

    def forward(self, in_data):
        # 特征提取阶段 - 保持backbone完整性
        x1 = self.encoder1(in_data)  # H×W×64
        x2 = self.encoder2(x1)  # H/2×W/2×128
        x3 = self.encoder4(x2)  # H/4×W/4×256
        x4 = self.encoder8(x3)  # H/8×W/8×512

        # 特征增强阶段 - 在backbone后进行
        f1 = self.feature_enhance1(x1)  # 48×H×W
        f2 = self.feature_enhance2(x2)  # 72×H/2×W/2
        f3 = self.feature_enhance3(x3)  # 144×H/4×W/4
        f4 = self.feature_enhance4(x4)  # 288×H/8×W/8

        # SMT分支
        a2_input = self.patch_embed(f1)  # H/2×W/2×32
        a2 = self.sam_block(a2_input)

        a3_input = self.downsample1(a2)  # H/4×W/4×64
        a3 = self.mix_block(a3_input)

        a4_input = self.downsample2(a3)  # H/8×W/8×128
        a4 = self.msa_block(a4_input)

        # 特征融合阶段 (EHFF)
        z4 = self.ehff4(f4, a4)  # 288×H/8×W/8
        z3 = self.ehff3(f3, a3, z4)  # 144×H/4×W/4
        z2 = self.ehff2(f2, a2, z3)  # 72×H/2×W/2
        z1 = self.ehff1(f1, z2)  # 48×H×W

        # 特征精炼阶段 (ERFE)
        F4 = self.erfe4(z4)  # 288×H/8×W/8
        F3 = self.erfe3(z3, F4)  # 144×H/4×W/4
        F2 = self.erfe2(z2, F3)  # 72×H/2×W/2
        F1 = self.erfe1(z1, F2)  # 48×H×W

        # 深度监督
        s1, s2, s3, s4, s5 = self.decoder(F1, F2, F3, F4)

        # 修复：正确的上采样到原始分辨率256x256
        s4 = self.upsample4(s4)  # 上采样到256x256
        s3 = self.upsample2(s3)  # 上采样到256x256

        return s1, s2, s3, s4, s5


class EHFNet_Res50(nn.Module):
    """基于ResNet50的MEAHANet - 参数优化版本

    通道数优化策略：
    - 低层特征(f1): 64 -> 48 (减少25%，保持细节)
    - 中低层特征(f2): 128 -> 96 (减少25%)
    - 中高层特征(f3): 256 -> 192 (减少25%)
    - 高层特征(f4): 512 -> 384 (减少25%)
    - SMT分支: 48/96/192 -> 32/64/128 (减少33%)
    - 解码器: 64 -> 48 (减少25%)
    """

    def __init__(self):
        super(EHFNet_Res50, self).__init__()

        # 注意：这里需要导入你的backbone模块
        from backbone.origin.from_origin import Backbone_ResNet50_in3
        from utils.tensor_ops import cus_sample

        # ResNet50 backbone - 保持完整性
        self.div_2, self.div_4, self.div_8, self.div_16, self.div_32 = Backbone_ResNet50_in3()

        self.upsample = cus_sample

        # 特征增强模块 - 优化通道数
        self.feature_enhance1 = nn.Sequential(
            AsymmetricConvBlock(64, 48),  # 64->48
            nn.Conv2d(48, 48, 1)
        )
        self.feature_enhance2 = nn.Sequential(
            AsymmetricConvBlock(256, 96),  # 256->96
            nn.Conv2d(96, 96, 1)
        )
        self.feature_enhance3 = nn.Sequential(
            AsymmetricConvBlock(512, 192),  # 512->192
            nn.Conv2d(192, 192, 1)
        )
        self.feature_enhance4 = nn.Sequential(
            AsymmetricConvBlock(1024, 384),  # 1024->384
            nn.Conv2d(384, 384, 1)
        )

        # SMT分支 - 更轻量化设计
        self.patch_embed = nn.Conv2d(48, 32, 3, stride=2, padding=1)  # 48->32
        self.sam_block = SAM(32)

        self.downsample1 = nn.Conv2d(32, 64, 3, stride=2, padding=1)  # 32->64
        self.mix_block = MixBlock(64)

        self.downsample2 = nn.Conv2d(64, 128, 3, stride=2, padding=1)  # 64->128
        self.msa_block = MSA(128)

        # EHFF模块 - 自适应融合
        self.ehff4 = EHFF(384, 128)  # 384+128
        self.ehff3 = EHFF(192, 64)  # 192+64
        self.ehff2 = EHFF(96, 32)  # 96+32
        self.ehff1 = EHFF_F1(48, 96)  # 48+96

        # ERFE模块
        self.erfe4 = ERFE(384)
        self.erfe3 = ERFE(192)
        self.erfe2 = ERFE(96)
        self.erfe1 = ERFE(48)

        # 深度监督解码器 - 优化版
        self.decoder = decoder_optimized(
            in_channels=[48, 96, 192, 384],
            unified_channels=48  # 统一通道数从64降到48
        )

        # 修复：正确的上采样操作
        self.upsample16 = nn.Upsample(scale_factor=16, mode='bilinear', align_corners=True)
        self.upsample8 = nn.Upsample(scale_factor=8, mode='bilinear', align_corners=True)
        self.upsample4 = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True)
        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)

    def forward(self, in_data):
        # 特征提取阶段 - 保持backbone完整性
        x1 = self.div_2(in_data)  # H/2×W/2×64
        x2 = self.div_4(x1)  # H/4×W/4×256
        x3 = self.div_8(x2)  # H/8×W/8×512
        x4 = self.div_16(x3)  # H/16×W/16×1024

        # 特征增强阶段 - 在backbone后进行
        f1 = self.feature_enhance1(x1)  # 48×H/2×W/2
        f2 = self.feature_enhance2(x2)  # 96×H/4×W/4
        f3 = self.feature_enhance3(x3)  # 192×H/8×W/8
        f4 = self.feature_enhance4(x4)  # 384×H/16×W/16

        # SMT分支
        a2_input = self.patch_embed(f1)  # H/4×W/4×32
        a2 = self.sam_block(a2_input)

        a3_input = self.downsample1(a2)  # H/8×W/8×64
        a3 = self.mix_block(a3_input)

        a4_input = self.downsample2(a3)  # H/16×W/16×128
        a4 = self.msa_block(a4_input)

        # 特征融合阶段 (EHFF)
        z4 = self.ehff4(f4, a4)  # 384×H/16×W/16
        z3 = self.ehff3(f3, a3, z4)  # 192×H/8×W/8
        z2 = self.ehff2(f2, a2, z3)  # 96×H/4×W/4
        z1 = self.ehff1(f1, z2)  # 48×H/2×W/2

        # 特征精炼阶段 (ERFE)
        F4 = self.erfe4(z4)  # 384×H/16×W/16
        F3 = self.erfe3(z3, F4)  # 192×H/8×W/8
        F2 = self.erfe2(z2, F3)  # 96×H/4×W/4
        F1 = self.erfe1(z1, F2)  # 48×H/2×W/2

        # 深度监督
        s1, s2, s3, s4, s5 = self.decoder(F1, F2, F3, F4)

        # 修复：正确的上采样到原始分辨率256x256
        s5 = self.upsample16(s5)  # (16,16) -> (256,256)
        s4 = self.upsample8(s4)  # (32,32) -> (256,256)
        s3 = self.upsample4(s3)  # (64,64) -> (256,256)
        s2 = self.upsample2(s2)  # (128,128) -> (256,256)
        # s1不需要上采样        # (256,256) -> (256,256)

        return s1, s2, s3, s4, s5


# 为了兼容原始代码，保留原始名称的别名
CSEPNet_VGG16 = EHFNet_VGG16
CSEPNET_Res50 = EHFNet_Res50

