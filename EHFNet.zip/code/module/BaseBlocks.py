# -*- coding: utf-8 -*-
# @Time    : 2019
# @Author  : Lart Pang
# @FileName: BaseBlocks.py
# @GitHub  : https://github.com/lartpang

import torch
import torch.nn as nn


class BasicConv2d(nn.Module):
    def __init__(
            self,
            in_planes,
            out_planes,
            kernel_size,
            stride=1,
            padding=0,
            dilation=1,
            groups=1,
            bias=False,
    ):
        super(BasicConv2d, self).__init__()

        self.basicconv = nn.Sequential(
            nn.Conv2d(
                in_planes,
                out_planes,
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                groups=groups,
                bias=bias,
            ),
            nn.BatchNorm2d(out_planes),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.basicconv(x)


class AsymmetricConvBlock(nn.Module):
    """非对称卷积块，包含3×3、1×3、3×1卷积"""

    def __init__(self, in_channels, out_channels):
        super(AsymmetricConvBlock, self).__init__()

        # 3×3卷积
        self.conv_3x3 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False)

        # 1×3卷积
        self.conv_1x3 = nn.Conv2d(in_channels, out_channels, kernel_size=(1, 3), padding=(0, 1), bias=False)

        # 3×1卷积
        self.conv_3x1 = nn.Conv2d(in_channels, out_channels, kernel_size=(3, 1), padding=(1, 0), bias=False)

        self.bn = nn.BatchNorm2d(out_channels * 3)
        self.relu = nn.ReLU(inplace=True)

        # 输出通道调整
        self.conv_out = nn.Conv2d(out_channels * 3, out_channels, kernel_size=1, bias=False)
        self.bn_out = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        # 并行执行三种卷积
        out_3x3 = self.conv_3x3(x)
        out_1x3 = self.conv_1x3(x)
        out_3x1 = self.conv_3x1(x)

        # 级联
        out = torch.cat([out_3x3, out_1x3, out_3x1], dim=1)
        out = self.bn(out)
        out = self.relu(out)

        # 通道调整
        out = self.conv_out(out)
        out = self.bn_out(out)
        out = self.relu(out)

        return out