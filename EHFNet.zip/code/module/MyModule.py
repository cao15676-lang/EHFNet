import torch
import torch.nn as nn
import torch.nn.functional as F
from utils.tensor_ops import cus_sample
import math

class DepthwiseSeparableConv(nn.Module):
    """3x3 depthwise + 1x1 pointwise"""
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.dw = nn.Conv2d(in_ch, in_ch, 3, padding=1, groups=in_ch, bias=False)
        self.pw = nn.Conv2d(in_ch, out_ch, 1, bias=False)
    def forward(self, x):
        return self.pw(self.dw(x))

class TransBasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size=2, stride=2, padding=0, dilation=1, bias=False):
        super(TransBasicConv2d, self).__init__()
        self.Deconv = nn.ConvTranspose2d(in_planes, out_planes,
                                         kernel_size=kernel_size, stride=stride,
                                         padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.Deconv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class CBR(nn.Module):
    """Conv + BN + ReLU"""

    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1):
        super(CBR, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.relu(self.bn(self.conv(x)))


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc = nn.Sequential(
            nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttentionWithSobel(nn.Module):
    """带Sobel边缘检测的空间注意力"""

    def __init__(self, kernel_size=7):
        super(SpatialAttentionWithSobel, self).__init__()
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

        # Sobel算子
        self.register_buffer('sobel_x',
                             torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32).view(1, 1, 3, 3))
        self.register_buffer('sobel_y',
                             torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32).view(1, 1, 3, 3))

        self.edge_conv = nn.Conv2d(1, 1, 3, padding=1, bias=False)

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)

        # Sobel边缘检测
        edge_x = F.conv2d(avg_out, self.sobel_x, padding=1)
        edge_y = F.conv2d(avg_out, self.sobel_y, padding=1)
        edge_magnitude = torch.sqrt(edge_x ** 2 + edge_y ** 2 + 1e-8)
        edge_enhanced = self.edge_conv(edge_magnitude)

        # 标准空间注意力
        spatial_out = torch.cat([avg_out, max_out], dim=1)
        spatial_out = self.conv1(spatial_out)

        # 结合边缘信息
        out = self.sigmoid(spatial_out + 0.5 * edge_enhanced)
        return out


class MHMC(nn.Module):
    """Multi-Head Mixed Convolution"""

    def __init__(self, channels, num_heads=4):
        super(MHMC, self).__init__()
        self.num_heads = num_heads
        self.channels_per_head = channels // num_heads

        self.dw_convs = nn.ModuleList()
        for i in range(num_heads):
            kernel_size = 3 + 2 * i  # 3, 5, 7, 9
            padding = kernel_size // 2
            self.dw_convs.append(
                nn.Conv2d(self.channels_per_head, self.channels_per_head,
                          kernel_size, padding=padding, groups=self.channels_per_head, bias=False)
            )

    def forward(self, x):
        b, c, h, w = x.shape
        x_split = x.chunk(self.num_heads, dim=1)

        outputs = []
        for i, conv in enumerate(self.dw_convs):
            outputs.append(conv(x_split[i]))

        return torch.cat(outputs, dim=1)


class SAA(nn.Module):
    """Scale-Aware Aggregation"""

    def __init__(self, channels, num_heads=4):
        super(SAA, self).__init__()
        self.num_heads = num_heads
        self.groups = channels // num_heads

        # 组内聚合
        self.intra_conv = nn.Conv2d(num_heads, num_heads * 2, 1, bias=False)
        self.intra_conv2 = nn.Conv2d(num_heads * 2, num_heads, 1, bias=False)

        # 组间聚合
        self.inter_conv = nn.Conv2d(channels, channels, 1, bias=False)

    def forward(self, x):
        b, c, h, w = x.shape
        # 重排列：从[B, C, H, W] -> [B, groups, heads, H, W]
        x_grouped = x.view(b, self.groups, self.num_heads, h, w)

        # 组内聚合
        x_intra = x_grouped.permute(0, 2, 1, 3, 4).contiguous().view(b, self.num_heads, -1, h * w)
        x_intra = x_intra.mean(dim=2, keepdim=True).view(b, self.num_heads, h, w)

        x_intra = self.intra_conv(x_intra)
        x_intra = F.relu(x_intra)
        x_intra = self.intra_conv2(x_intra)

        # 广播回原始形状
        x_intra = x_intra.unsqueeze(2).expand(b, self.num_heads, self.groups, h, w)
        x_intra = x_intra.contiguous().view(b, c, h, w)

        # 组间聚合
        out = self.inter_conv(x + x_intra)
        return out


class SAM(nn.Module):
    """Scale-Aware Modulation"""

    def __init__(self, channels, num_heads=4):
        super(SAM, self).__init__()
        self.mhmc = MHMC(channels, num_heads)
        self.saa = SAA(channels, num_heads)
        self.value_conv = nn.Conv2d(channels, channels, 1, bias=False)
        self.modulator_conv = nn.Conv2d(channels, channels, 1, bias=False)

    def forward(self, x):
        # 计算调制器
        modulator = self.mhmc(x)
        modulator = self.saa(modulator)
        modulator = self.modulator_conv(modulator)

        # 计算值
        value = self.value_conv(x)

        # 元素级相乘
        out = modulator * value
        return out


class MSA(nn.Module):
    """Multi-Head Self-Attention"""

    def __init__(self, channels, num_heads=8):
        super(MSA, self).__init__()
        self.num_heads = num_heads
        self.head_dim = channels // num_heads
        self.scale = self.head_dim ** -0.5

        self.qkv = nn.Linear(channels, channels * 3, bias=False)
        self.proj = nn.Linear(channels, channels)

    def forward(self, x):
        b, c, h, w = x.shape
        x_flat = x.flatten(2).transpose(1, 2)  # [B, H*W, C]

        qkv = self.qkv(x_flat).reshape(b, h * w, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)

        out = (attn @ v).transpose(1, 2).reshape(b, h * w, c)
        out = self.proj(out)

        return out.transpose(1, 2).reshape(b, c, h, w)


class MixBlock(nn.Module):
    """混合块：SAM + MSA"""

    def __init__(self, channels):
        super(MixBlock, self).__init__()
        self.sam = SAM(channels)
        self.msa = MSA(channels)
        self.ln1 = nn.LayerNorm(channels)
        self.ln2 = nn.LayerNorm(channels)

    def forward(self, x):
        # SAM分支
        sam_out = self.sam(x)

        # MSA分支
        b, c, h, w = x.shape
        x_ln = self.ln1(x.flatten(2).transpose(1, 2)).transpose(1, 2).reshape(b, c, h, w)
        msa_out = self.msa(x_ln)
        msa_out = self.ln2(msa_out.flatten(2).transpose(1, 2)).transpose(1, 2).reshape(b, c, h, w)

        return sam_out + msa_out


class EHFF(nn.Module):
    """
    Edge-aware Heterogeneous Feature Fusion (EHFF)
    对应论文式(3)–(12)、图5：
      - CNN分支：LCEM  -> (3)(4)(5)
      - SMT分支：GSEM  -> (6)(7)
      - 融合与空间注意+Sobel -> (8)(9)
      - 自顶向下递归(含上层特征)：-> (10)，i=1 时遵循 (11)(12)
    兼容原 EHFF 的接口：
      __init__(f_channels, a_channels)
      forward(f, a, upper_z=None) -> z_i
    """
    def __init__(self, f_channels: int, a_channels: int):
        super().__init__()
        self.f_channels = f_channels

        # -------- 通道/尺寸对齐 --------
        self.align_a = nn.Conv2d(a_channels, f_channels, 1, bias=False) if a_channels != f_channels else nn.Identity()

        # -------- CNN分支：LCEM --------
        # Avg 5x5 作 Pavg，GN 稳定分布；β 为可学习缩放
        self.avg5 = nn.AvgPool2d(kernel_size=5, stride=1, padding=2)
        # 论文(5)中的 SE，这里直接复用通道注意力（等价于 SE）
        self.se_f = nn.Sequential(
            nn.Conv2d(f_channels, max(8, f_channels // 8), 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(max(8, f_channels // 8), f_channels, 1, bias=False),
            nn.Sigmoid()
        )
        self.gn_f = nn.GroupNorm(1, f_channels)  # GN(1, C) 等价于跨通道归一化，安全不挑 group
        self.beta = nn.Parameter(torch.tensor(1.0))

        # -------- SMT分支：GSEM --------
        red = max(8, f_channels // 4)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.mlp_a = nn.Sequential(
            nn.Conv2d(f_channels, red, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(red, f_channels, 1, bias=False),
            nn.Sigmoid()
        )
        self.dws_smooth = DepthwiseSeparableConv(f_channels, f_channels)
        self.gamma = nn.Parameter(torch.tensor(1.0))

        # -------- 跨模态融合 T：Conv1x1 -> DWSConv -> BN -> ReLU --------
        self.fuse_1x1 = nn.Conv2d(f_channels * 2, f_channels, 1, bias=False)
        self.fuse_dws = DepthwiseSeparableConv(f_channels, f_channels)
        self.fuse_bn  = nn.BatchNorm2d(f_channels)

        # -------- 空间注意 + Sobel 边缘先验 --------
        self.sa_conv = nn.Conv2d(2, 1, kernel_size=7, padding=3, bias=False)
        self.edge_conv = nn.Conv2d(1, 1, kernel_size=3, padding=1, bias=False)
        # Sobel 卷积核（对均值图）
        self.register_buffer('sobel_x', torch.tensor([[-1, 0, 1],
                                                     [-2, 0, 2],
                                                     [-1, 0, 1]], dtype=torch.float32).view(1, 1, 3, 3))
        self.register_buffer('sobel_y', torch.tensor([[-1, -2, -1],
                                                     [ 0,  0,  0],
                                                     [ 1,  2,  1]], dtype=torch.float32).view(1, 1, 3, 3))

        # -------- 上层 z 的动态通道对齐（仅在首次用到时创建）--------
        self.upper_align: nn.Module | None = None

    @staticmethod
    def _resize_like(src: torch.Tensor, ref: torch.Tensor) -> torch.Tensor:
        if src.shape[2:] != ref.shape[2:]:
            src = F.interpolate(src, size=ref.shape[2:], mode='bilinear', align_corners=False)
        return src

    def forward(self, f: torch.Tensor, a: torch.Tensor, upper_z: torch.Tensor | None = None) -> torch.Tensor:
        # 1) 尺寸/通道对齐
        a = self._resize_like(a, f)
        a_aligned = self.align_a(a)

        # 2) CNN分支：LCEM（式(3)(4)(5)）
        # x = f - Avg5x5(f)
        x = f - self.avg5(f)
        # δ = x * (1 + α * tanh(x)), α=0.6
        delta = x * (1.0 + 0.6 * torch.tanh(x))
        # SE 权重 + 可学习缩放 β
        w_se = self.se_f(f)
        f_enh = self.gn_f(f + delta * w_se * self.beta)

        # 3) SMT分支：GSEM（式(6)(7)）
        w_a = self.mlp_a(self.gap(a_aligned))           # ωsigmoid
        a_mod = a_aligned * w_a                          # a' ⊙ ω
        a_smooth = self.dws_smooth(a_mod)                # DWSConv 平滑
        a_enh = a_aligned + self.gamma * a_smooth        # 残差调制

        # 4) 跨模态融合 T（式(9)）
        T = torch.cat([f_enh, a_enh], dim=1)
        T = self.fuse_1x1(T)
        T = self.fuse_dws(T)
        T = self.fuse_bn(T)
        T = F.relu(T, inplace=True)

        # 5) 空间注意 + Sobel 先验（式(8)）
        avg_map = torch.mean(T, dim=1, keepdim=True)
        max_map, _ = torch.max(T, dim=1, keepdim=True)
        sa_core = self.sa_conv(torch.cat([avg_map, max_map], dim=1))  # SA(mean,max)

        edge_x = F.conv2d(avg_map, self.sobel_x, padding=1)
        edge_y = F.conv2d(avg_map, self.sobel_y, padding=1)
        edge_mag = torch.sqrt(edge_x ** 2 + edge_y ** 2 + 1e-8)
        edge_term = self.edge_conv(edge_mag)

        w_sa = torch.sigmoid(sa_core + 0.8 * edge_term)  # ω_sa

        # 6) 顶向下递归（式(10)；i=1 时等价于式(11)(12)的形态）
        T_att = T * w_sa

        z_next = None
        if upper_z is not None:
            upper_z = self._resize_like(upper_z, T_att)
            if (self.upper_align is None) or (self.upper_align.in_channels != upper_z.shape[1]):
                self.upper_align = nn.Conv2d(upper_z.shape[1], self.f_channels, 1, bias=False).to(upper_z.device)
            z_next = self.upper_align(upper_z)

        if z_next is None:
            out = T_att + f + a_aligned          # i=4 时对应 z5=0
        else:
            out = T_att + f + a_aligned + z_next # i=3/2/1 时加上 z_{i+1}

        return out

class EHFF_F1(nn.Module):
    """
    EHFF variant for i=1 (fuse f1 & z2):
      - CNN分支: LCEM (式(3)(4)(5))
      - Top-down分支: GSEM (式(6)(7))，对齐后的 z2 视作 'a′'
      - 融合: Conv1×1 → DWSConv → BN → ReLU (式(9))
      - 空间注意: SA(mean,max) + 0.8×Sobel边缘先验 (式(8))
      - 输出: z1 = ω_sa ⊙ T + f1 + z2 (式(12))
    接口与原 EHFF_F1 完全一致：__init__(f1_channels, z2_channels); forward(f1, z2)
    """

    def __init__(self, f1_channels: int, z2_channels: int):
        super().__init__()
        self.f1_channels = f1_channels

        # ========== 尺寸/通道对齐（i=1：先双线性对齐空间，再1×1通道对齐） ==========
        self.align_z2 = nn.Conv2d(z2_channels, f1_channels, 1, bias=False) \
            if z2_channels != f1_channels else nn.Identity()

        # ========== CNN分支：LCEM（式(3)(4)(5)）==========
        self.avg5 = nn.AvgPool2d(kernel_size=5, stride=1, padding=2)   # Pavg
        mid_se = max(8, f1_channels // 8)
        self.se_f1 = nn.Sequential(                                 # SE
            nn.Conv2d(f1_channels, mid_se, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_se, f1_channels, 1, bias=False),
            nn.Sigmoid()
        )
        self.gn_f1 = nn.GroupNorm(1, f1_channels)                   # GN(1,C)
        self.beta = nn.Parameter(torch.tensor(1.0))                 # 可学习缩放 β

        # ========== 顶向下分支：GSEM（式(6)(7)）==========
        red = max(8, f1_channels // 4)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.mlp_z2 = nn.Sequential(
            nn.Conv2d(f1_channels, red, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(red, f1_channels, 1, bias=False),
            nn.Sigmoid()
        )
        # DWSConv 平滑
        self.dws_smooth = nn.Sequential(
            nn.Conv2d(f1_channels, f1_channels, 3, padding=1, groups=f1_channels, bias=False),  # DW
            nn.Conv2d(f1_channels, f1_channels, 1, bias=False)                                   # PW
        )
        self.gamma = nn.Parameter(torch.tensor(1.0))

        # ========== 跨分支融合 T（式(9)）==========
        self.fuse_1x1 = nn.Conv2d(f1_channels * 2, f1_channels, 1, bias=False)
        self.fuse_dws = nn.Sequential(
            nn.Conv2d(f1_channels, f1_channels, 3, padding=1, groups=f1_channels, bias=False),
            nn.Conv2d(f1_channels, f1_channels, 1, bias=False)
        )
        self.fuse_bn = nn.BatchNorm2d(f1_channels)

        # ========== 空间注意 + Sobel 先验（式(8)）==========
        self.sa_conv = nn.Conv2d(2, 1, kernel_size=7, padding=3, bias=False)
        self.edge_conv = nn.Conv2d(1, 1, kernel_size=3, padding=1, bias=False)
        self.register_buffer('sobel_x', torch.tensor([[-1, 0, 1],
                                                      [-2, 0, 2],
                                                      [-1, 0, 1]], dtype=torch.float32).view(1, 1, 3, 3))
        self.register_buffer('sobel_y', torch.tensor([[-1, -2, -1],
                                                      [ 0,  0,  0],
                                                      [ 1,  2,  1]], dtype=torch.float32).view(1, 1, 3, 3))

    @staticmethod
    def _resize_like(src: torch.Tensor, ref: torch.Tensor) -> torch.Tensor:
        if src.shape[2:] != ref.shape[2:]:
            src = F.interpolate(src, size=ref.shape[2:], mode='bilinear', align_corners=False)
        return src

    def forward(self, f1: torch.Tensor, z2: torch.Tensor) -> torch.Tensor:
        # 1) i=1 对齐：空间+通道（论文式(11)前置说明）
        z2 = self._resize_like(z2, f1)
        z2_aligned = self.align_z2(z2)

        # 2) LCEM on f1（式(3)(4)(5)）
        x = f1 - self.avg5(f1)                              # x = PWS(f1, Pavg(f1))
        delta = x * (1.0 + 0.6 * torch.tanh(x))             # δ = x · (1 + 0.6·tanh(x))
        w_se = self.se_f1(f1)                                # SE(f1)
        f1_enh = self.gn_f1(f1 + delta * w_se * self.beta)   # GN(f1 + δ·SE(f1)·β)

        # 3) GSEM on z2（式(6)(7)）
        w = self.mlp_z2(self.gap(z2_aligned))                # ωsigmoid
        z2_mod = z2_aligned * w
        z2_smooth = self.dws_smooth(z2_mod)                  # DWSConv
        z2_enh = z2_aligned + self.gamma * z2_smooth         # 残差调制

        # 4) 融合 T（式(9)）
        T = torch.cat([f1_enh, z2_enh], dim=1)
        T = self.fuse_1x1(T)
        T = self.fuse_dws(T)
        T = self.fuse_bn(T)
        T = F.relu(T, inplace=True)

        # 5) 空间注意 + Sobel 先验（式(8)）
        avg_map = torch.mean(T, dim=1, keepdim=True)
        max_map, _ = torch.max(T, dim=1, keepdim=True)
        sa_core = self.sa_conv(torch.cat([avg_map, max_map], dim=1))
        edge_x = F.conv2d(avg_map, self.sobel_x, padding=1)
        edge_y = F.conv2d(avg_map, self.sobel_y, padding=1)
        edge_mag = torch.sqrt(edge_x ** 2 + edge_y ** 2 + 1e-8)
        edge_term = self.edge_conv(edge_mag)
        w_sa = torch.sigmoid(sa_core + 0.8 * edge_term)      # 0.8 系数来自式(8)

        T_att = T * w_sa

        # 6) 输出（式(12)）：z1 = ωsa ⊙ T + f1 + z2
        out = T_att + f1 + z2_aligned
        return out


class ERFE(nn.Module):
    """Edge-Refined Multi-Scale Feature Enhancement"""

    def __init__(self, channels):
        super(ERFE, self).__init__()
        self.channels = channels

        # 上层特征融合
        self.upper_fusion = nn.Sequential(
            CBR(channels * 2, channels),
            CBR(channels, channels)
        )

        self.conv1 = CBR(channels, channels)

        # 边界增强
        self.boundary_enhance = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False),  # DW Conv
            nn.Conv2d(channels, channels, 1, bias=False),  # PW Conv
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True)
        )

        self.conv2 = nn.Sequential(
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.GroupNorm(32, channels),
            nn.ReLU(inplace=True)
        )

        self.l2_norm = nn.GroupNorm(1, channels)

        # 动态创建的上层特征对齐层
        self.upper_align = None

    def forward(self, z, upper_f=None):
        if upper_f is not None:
            # 空间对齐
            if upper_f.shape[2:] != z.shape[2:]:
                upper_f = F.interpolate(upper_f, size=z.shape[2:], mode='bilinear', align_corners=False)

            # 动态创建通道对齐层（仅在第一次使用时创建）
            if self.upper_align is None or self.upper_align.in_channels != upper_f.shape[1]:
                self.upper_align = nn.Conv2d(upper_f.shape[1], self.channels, 1, bias=False).to(upper_f.device)

            # 通道对齐
            upper_f_aligned = self.upper_align(upper_f)

            # 特征融合
            z = torch.cat([z, upper_f_aligned], dim=1)
            z = self.upper_fusion(z)

        g1 = self.conv1(z)

        # 边界增强
        enhanced_g1 = self.boundary_enhance(g1) * 0.2

        # L2归一化和进一步处理
        g2 = self.l2_norm(enhanced_g1)
        g2 = self.conv2(g2)

        # 哈达玛积
        out = enhanced_g1 * g2

        return out


class decoder(nn.Module):
    """多尺度解码器 - 统一到64通道"""

    def __init__(self):
        super(decoder, self).__init__()

        # 统一通道数
        self.unified_channels = 64

        # 通道统一层 - 预定义常见的通道数转换
        self.channel_conv1 = nn.Conv2d(64, self.unified_channels, 1)  # F1: 64->64
        self.channel_conv2 = nn.Conv2d(128, self.unified_channels, 1)  # F2: 128->64
        self.channel_conv3 = nn.Conv2d(256, self.unified_channels, 1)  # F3: 256->64
        self.channel_conv4 = nn.Conv2d(512, self.unified_channels, 1)  # F4: 512->64

        # 解码器模块
        self.decoder4 = nn.Sequential(
            BasicConv2d(self.unified_channels, self.unified_channels, 3, padding=1),
            BasicConv2d(self.unified_channels, self.unified_channels, 3, padding=1),
            nn.Dropout(0.3),
            TransBasicConv2d(self.unified_channels, self.unified_channels, kernel_size=2, stride=2)
        )
        self.S4 = nn.Conv2d(self.unified_channels, 1, 3, stride=1, padding=1)

        self.decoder3 = nn.Sequential(
            BasicConv2d(self.unified_channels, self.unified_channels, 3, padding=1),
            BasicConv2d(self.unified_channels, self.unified_channels, 3, padding=1),
            nn.Dropout(0.3),
            TransBasicConv2d(self.unified_channels, self.unified_channels, kernel_size=2, stride=2)
        )
        self.S3 = nn.Conv2d(self.unified_channels, 1, 3, stride=1, padding=1)

        self.decoder2 = nn.Sequential(
            BasicConv2d(self.unified_channels, self.unified_channels, 3, padding=1),
            BasicConv2d(self.unified_channels, self.unified_channels, 3, padding=1),
            nn.Dropout(0.3),
            TransBasicConv2d(self.unified_channels, self.unified_channels, kernel_size=2, stride=2)
        )
        self.S2 = nn.Conv2d(self.unified_channels, 1, 3, stride=1, padding=1)

        self.decoder1 = nn.Sequential(
            BasicConv2d(self.unified_channels, self.unified_channels, 3, padding=1),
            BasicConv2d(self.unified_channels, self.unified_channels, 3, padding=1),
            nn.Dropout(0.3),
            TransBasicConv2d(self.unified_channels, self.unified_channels, kernel_size=2, stride=2)
        )
        self.S1 = nn.Conv2d(self.unified_channels, 1, 3, stride=1, padding=1)

        # 第5个输出（最深层）
        self.decoder5 = nn.Sequential(
            BasicConv2d(self.unified_channels, self.unified_channels, 3, padding=1),
            BasicConv2d(self.unified_channels, self.unified_channels, 3, padding=1),
            nn.Dropout(0.3)
        )
        self.S5 = nn.Conv2d(self.unified_channels, 1, 3, stride=1, padding=1)

    def forward(self, F1, F2, F3, F4):
        # 通道统一
        x1 = self.channel_conv1(F1)  # 64 -> 64
        x2 = self.channel_conv2(F2)  # 128 -> 64
        x3 = self.channel_conv3(F3)  # 256 -> 64
        x4 = self.channel_conv4(F4)  # 512 -> 64

        # 解码和预测
        # 最深层输出
        x5_up = self.decoder5(x4)
        s5 = self.S5(x5_up)

        x4_up = self.decoder4(x4)
        s4 = self.S4(x4_up)

        x3_up = self.decoder3(x3)
        s3 = self.S3(x3_up)

        x2_up = self.decoder2(x2)
        s2 = self.S2(x2_up)

        x1_up = self.decoder1(x1)
        s1 = self.S1(x1_up)

        return s1, s2, s3, s4, s5